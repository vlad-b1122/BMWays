package com.example.bmways.modelos;

public class Tutorial {
    private int idTutorial;
    private String nombreTutorial;
    private String descripccion;
    private String imagen;
    private String video;
    private Motor motor;



}
